Compile:
divi-scripts build